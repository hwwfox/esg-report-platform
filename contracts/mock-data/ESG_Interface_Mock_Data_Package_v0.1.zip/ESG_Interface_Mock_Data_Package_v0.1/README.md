# ESG报告软件 接口Mock数据包 v0.1

## 用途

本数据包用于前端在后端接口未完全完成前进行页面开发、状态展示、组件联调和E2E流程模拟。

## 目录说明

- `auth/`：登录、当前用户、租户切换
- `enterprises/`：企业列表、企业详情、组织架构
- `users/`：用户与权限
- `projects/`：项目列表、项目工作台、项目创建结果
- `standards/`：标准、议题、指标
- `gics/`：GICS识别结果
- `peer/`：同行推荐、同行报告、解析结果
- `recommendations/`：推荐标准、推荐议题、推荐来源
- `topics/`：项目议题、指标选择
- `assignments/`：分配推荐、任务预览
- `tasks/`：部门采集、部门审核
- `esg-data/`：ESG数据表和来源
- `knowledge/`：知识库搜索和文件详情
- `chapters/`：章节结构、材料包、章节版本、来源引用
- `review/`：章节校对、全文校对
- `exports/`：导出任务和文件
- `ai/`：AI模型、调用日志、成本统计
- `audit/`：操作日志
- `common/`：异步任务、错误响应、枚举

## 使用建议

1. 前端可按 OpenAPI 路径映射到对应 mock 文件。
2. 建议在开发环境中使用 MSW、Mock Service Worker、Vite proxy、Next.js route handler 或 Apifox Mock Server 加载。
3. Mock数据中的ID、状态和字段尽量与 P0 OpenAPI 文档保持一致。
4. 所有AI结果均设计为“候选结果”，前端应展示人工确认操作。
